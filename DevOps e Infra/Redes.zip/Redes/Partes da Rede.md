
---
### Routers

> Suas funções principais são: expandir a rede, segmentar o tráfego e conectar duas redes diferentes.

### Links

Podem ser:

1. **Full Duplex**: transmissão bidirecional simultânea (envia e recebe ao mesmo tempo).
2. **Half Duplex**: transmissão bidirecional, mas não simultânea (envia ou recebe em tempos diferentes).
3. **Simples**: transmissão unidirecional (apenas envia ou apenas recebe).